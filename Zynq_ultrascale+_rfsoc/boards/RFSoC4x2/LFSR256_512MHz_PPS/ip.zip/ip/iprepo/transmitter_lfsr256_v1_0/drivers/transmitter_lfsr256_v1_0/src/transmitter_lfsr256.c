#include "transmitter_lfsr256.h"
#ifndef __linux__
int transmitter_lfsr256_CfgInitialize(transmitter_lfsr256 *InstancePtr, transmitter_lfsr256_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->transmitter_lfsr256_BaseAddress = ConfigPtr->transmitter_lfsr256_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void transmitter_lfsr256_observation_point_write(transmitter_lfsr256 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr256_WriteReg(InstancePtr->transmitter_lfsr256_BaseAddress, 12, Data);
}
u32 transmitter_lfsr256_observation_point_read(transmitter_lfsr256 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr256_ReadReg(InstancePtr->transmitter_lfsr256_BaseAddress, 12);
    return Data;
}
void transmitter_lfsr256_modulation_write(transmitter_lfsr256 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr256_WriteReg(InstancePtr->transmitter_lfsr256_BaseAddress, 8, Data);
}
u32 transmitter_lfsr256_modulation_read(transmitter_lfsr256 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr256_ReadReg(InstancePtr->transmitter_lfsr256_BaseAddress, 8);
    return Data;
}
void transmitter_lfsr256_enable_tx_write(transmitter_lfsr256 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr256_WriteReg(InstancePtr->transmitter_lfsr256_BaseAddress, 4, Data);
}
u32 transmitter_lfsr256_enable_tx_read(transmitter_lfsr256 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr256_ReadReg(InstancePtr->transmitter_lfsr256_BaseAddress, 4);
    return Data;
}
void transmitter_lfsr256_enable_data_write(transmitter_lfsr256 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr256_WriteReg(InstancePtr->transmitter_lfsr256_BaseAddress, 0, Data);
}
u32 transmitter_lfsr256_enable_data_read(transmitter_lfsr256 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr256_ReadReg(InstancePtr->transmitter_lfsr256_BaseAddress, 0);
    return Data;
}
