/**
* @file transmitter_simple_sinit.c
*
* The implementation of the transmitter_simple driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "transmitter_simple.h"
extern transmitter_simple_Config transmitter_simple_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type transmitter_simple_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
transmitter_simple_Config *transmitter_simple_LookupConfig(u16 DeviceId) {
    transmitter_simple_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_TRANSMITTER_SIMPLE_NUM_INSTANCES; Index++) {
        if (transmitter_simple_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &transmitter_simple_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int transmitter_simple_Initialize(transmitter_simple *InstancePtr, u16 DeviceId) {
    transmitter_simple_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = transmitter_simple_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return transmitter_simple_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
