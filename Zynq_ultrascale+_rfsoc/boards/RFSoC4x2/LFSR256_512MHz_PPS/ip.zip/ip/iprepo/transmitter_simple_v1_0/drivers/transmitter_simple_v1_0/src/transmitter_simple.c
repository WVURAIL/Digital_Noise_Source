#include "transmitter_simple.h"
#ifndef __linux__
int transmitter_simple_CfgInitialize(transmitter_simple *InstancePtr, transmitter_simple_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->transmitter_simple_BaseAddress = ConfigPtr->transmitter_simple_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void transmitter_simple_observation_point_write(transmitter_simple *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_simple_WriteReg(InstancePtr->transmitter_simple_BaseAddress, 12, Data);
}
u32 transmitter_simple_observation_point_read(transmitter_simple *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_simple_ReadReg(InstancePtr->transmitter_simple_BaseAddress, 12);
    return Data;
}
void transmitter_simple_modulation_write(transmitter_simple *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_simple_WriteReg(InstancePtr->transmitter_simple_BaseAddress, 8, Data);
}
u32 transmitter_simple_modulation_read(transmitter_simple *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_simple_ReadReg(InstancePtr->transmitter_simple_BaseAddress, 8);
    return Data;
}
void transmitter_simple_enable_tx_write(transmitter_simple *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_simple_WriteReg(InstancePtr->transmitter_simple_BaseAddress, 4, Data);
}
u32 transmitter_simple_enable_tx_read(transmitter_simple *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_simple_ReadReg(InstancePtr->transmitter_simple_BaseAddress, 4);
    return Data;
}
void transmitter_simple_enable_data_write(transmitter_simple *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_simple_WriteReg(InstancePtr->transmitter_simple_BaseAddress, 0, Data);
}
u32 transmitter_simple_enable_data_read(transmitter_simple *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_simple_ReadReg(InstancePtr->transmitter_simple_BaseAddress, 0);
    return Data;
}
