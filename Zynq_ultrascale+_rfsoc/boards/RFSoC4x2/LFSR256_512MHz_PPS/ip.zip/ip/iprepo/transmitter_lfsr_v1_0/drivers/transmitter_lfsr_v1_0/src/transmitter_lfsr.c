#include "transmitter_lfsr.h"
#ifndef __linux__
int transmitter_lfsr_CfgInitialize(transmitter_lfsr *InstancePtr, transmitter_lfsr_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->transmitter_lfsr_BaseAddress = ConfigPtr->transmitter_lfsr_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void transmitter_lfsr_observation_point_write(transmitter_lfsr *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr_WriteReg(InstancePtr->transmitter_lfsr_BaseAddress, 12, Data);
}
u32 transmitter_lfsr_observation_point_read(transmitter_lfsr *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr_ReadReg(InstancePtr->transmitter_lfsr_BaseAddress, 12);
    return Data;
}
void transmitter_lfsr_modulation_write(transmitter_lfsr *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr_WriteReg(InstancePtr->transmitter_lfsr_BaseAddress, 8, Data);
}
u32 transmitter_lfsr_modulation_read(transmitter_lfsr *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr_ReadReg(InstancePtr->transmitter_lfsr_BaseAddress, 8);
    return Data;
}
void transmitter_lfsr_enable_tx_write(transmitter_lfsr *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr_WriteReg(InstancePtr->transmitter_lfsr_BaseAddress, 4, Data);
}
u32 transmitter_lfsr_enable_tx_read(transmitter_lfsr *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr_ReadReg(InstancePtr->transmitter_lfsr_BaseAddress, 4);
    return Data;
}
void transmitter_lfsr_enable_data_write(transmitter_lfsr *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr_WriteReg(InstancePtr->transmitter_lfsr_BaseAddress, 0, Data);
}
u32 transmitter_lfsr_enable_data_read(transmitter_lfsr *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr_ReadReg(InstancePtr->transmitter_lfsr_BaseAddress, 0);
    return Data;
}
