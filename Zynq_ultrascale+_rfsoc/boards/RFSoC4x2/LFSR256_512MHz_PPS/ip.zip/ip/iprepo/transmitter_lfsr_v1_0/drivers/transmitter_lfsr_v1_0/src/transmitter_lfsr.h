#ifndef TRANSMITTER_LFSR__H
#define TRANSMITTER_LFSR__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "transmitter_lfsr_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 transmitter_lfsr_BaseAddress;
} transmitter_lfsr_Config;
#endif
/**
* The transmitter_lfsr driver instance data. The user is required to
* allocate a variable of this type for every transmitter_lfsr device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 transmitter_lfsr_BaseAddress;
    u32 IsReady;
} transmitter_lfsr;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define transmitter_lfsr_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define transmitter_lfsr_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define transmitter_lfsr_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define transmitter_lfsr_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int transmitter_lfsr_Initialize(transmitter_lfsr *InstancePtr, u16 DeviceId);
transmitter_lfsr_Config* transmitter_lfsr_LookupConfig(u16 DeviceId);
int transmitter_lfsr_CfgInitialize(transmitter_lfsr *InstancePtr, transmitter_lfsr_Config *ConfigPtr);
#else
int transmitter_lfsr_Initialize(transmitter_lfsr *InstancePtr, const char* InstanceName);
int transmitter_lfsr_Release(transmitter_lfsr *InstancePtr);
#endif
/**
* Write to observation_point gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the observation_point instance to operate on.
* @param	Data is value to be written to gateway observation_point.
*
* @return	None.
*
* @note    .
*
*/
void transmitter_lfsr_observation_point_write(transmitter_lfsr *InstancePtr, u32 Data);
/**
* Read from observation_point gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the observation_point instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 transmitter_lfsr_observation_point_read(transmitter_lfsr *InstancePtr);
/**
* Write to modulation gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the modulation instance to operate on.
* @param	Data is value to be written to gateway modulation.
*
* @return	None.
*
* @note    .
*
*/
void transmitter_lfsr_modulation_write(transmitter_lfsr *InstancePtr, u32 Data);
/**
* Read from modulation gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the modulation instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 transmitter_lfsr_modulation_read(transmitter_lfsr *InstancePtr);
/**
* Write to enable_tx gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the enable_tx instance to operate on.
* @param	Data is value to be written to gateway enable_tx.
*
* @return	None.
*
* @note    .
*
*/
void transmitter_lfsr_enable_tx_write(transmitter_lfsr *InstancePtr, u32 Data);
/**
* Read from enable_tx gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the enable_tx instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 transmitter_lfsr_enable_tx_read(transmitter_lfsr *InstancePtr);
/**
* Write to enable_data gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the enable_data instance to operate on.
* @param	Data is value to be written to gateway enable_data.
*
* @return	None.
*
* @note    .
*
*/
void transmitter_lfsr_enable_data_write(transmitter_lfsr *InstancePtr, u32 Data);
/**
* Read from enable_data gateway of transmitter_lfsr. Assignments are LSB-justified.
*
* @param	InstancePtr is the enable_data instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 transmitter_lfsr_enable_data_read(transmitter_lfsr *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
