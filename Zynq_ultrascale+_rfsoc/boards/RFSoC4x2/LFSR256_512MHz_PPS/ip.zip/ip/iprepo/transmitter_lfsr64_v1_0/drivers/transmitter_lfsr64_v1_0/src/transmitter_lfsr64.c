#include "transmitter_lfsr64.h"
#ifndef __linux__
int transmitter_lfsr64_CfgInitialize(transmitter_lfsr64 *InstancePtr, transmitter_lfsr64_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->transmitter_lfsr64_BaseAddress = ConfigPtr->transmitter_lfsr64_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void transmitter_lfsr64_observation_point_write(transmitter_lfsr64 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr64_WriteReg(InstancePtr->transmitter_lfsr64_BaseAddress, 12, Data);
}
u32 transmitter_lfsr64_observation_point_read(transmitter_lfsr64 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr64_ReadReg(InstancePtr->transmitter_lfsr64_BaseAddress, 12);
    return Data;
}
void transmitter_lfsr64_modulation_write(transmitter_lfsr64 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr64_WriteReg(InstancePtr->transmitter_lfsr64_BaseAddress, 8, Data);
}
u32 transmitter_lfsr64_modulation_read(transmitter_lfsr64 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr64_ReadReg(InstancePtr->transmitter_lfsr64_BaseAddress, 8);
    return Data;
}
void transmitter_lfsr64_enable_tx_write(transmitter_lfsr64 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr64_WriteReg(InstancePtr->transmitter_lfsr64_BaseAddress, 4, Data);
}
u32 transmitter_lfsr64_enable_tx_read(transmitter_lfsr64 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr64_ReadReg(InstancePtr->transmitter_lfsr64_BaseAddress, 4);
    return Data;
}
void transmitter_lfsr64_enable_data_write(transmitter_lfsr64 *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    transmitter_lfsr64_WriteReg(InstancePtr->transmitter_lfsr64_BaseAddress, 0, Data);
}
u32 transmitter_lfsr64_enable_data_read(transmitter_lfsr64 *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = transmitter_lfsr64_ReadReg(InstancePtr->transmitter_lfsr64_BaseAddress, 0);
    return Data;
}
